#!/usr/bin/env python
# -*- coding: utf-8 -*-
# Programa Servidor

import socket
#from socket import error
import sys
from datetime import datetime
import os

RUTA_ARCHIVOS = '/Users/esetipo/Documents/Universidad/Cliente-Servidor-Python/archivos/'

def get_ip():
    s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
    try:
        # doesn't even have to be reachable
        s.connect(('0.0.0.1', 1))
        IP = s.getsockname()[0]
    except Exception:
        IP = '127.0.0.1'
    finally:
        s.close()
    return IP

if len(sys.argv) != 2:
    print ("Agregar el puerto donde se va a ofrecer el servicio desarrollado.")
    sys.exit(0)

IP = get_ip()  
PUERTO = int(sys.argv[1])

print ("\nServicio se va a configurar en el puerto: ", PUERTO, "en el servidor ", IP, "\n")

def listarArchivos():
    pass

socket_servidor = socket.socket(socket.AF_INET, socket.SOCK_STREAM)

# Enlace del socket con la IP y el puerto
socket_servidor.bind((IP, PUERTO))

# Escuchar conexiones entrantes con el metodo listen,
# El parametro indica el numero de conexiones entrantes que vamos a aceptar
socket_servidor.listen(2)

print ("Servicio configurado en puerto ", PUERTO, "en el servidor ", IP, "\n")

try:
    while True:
        print ("Esperando conexión de un cliente ...")
        # Instanciar objeto socket_cliente para recibir datos,
        # direccion_cliente recibe la tupla de conexion: IP y puerto
        socket_cliente, direccion_cliente = socket_servidor.accept()
        print ("Cliente conectado desde: ", direccion_cliente)
        cont =0
        while True:
            try:
                recibido = socket_cliente.recv(1024).decode('utf-8')
                print (direccion_cliente[0] + " >> ", recibido)

                if recibido == "finalizar()":
                    print ("Cliente finalizo la conexion.")
                    print ("Cerrando la conexion con el cliente ...")
                    socket_cliente.close()
                    print ("Conexion con el cliente cerrado.")
                    break

                if recibido == "enviararchivo()":
                    #listarArchivos()
                    diaactual = datetime.now()
                    nombrearchivo = str(diaactual) + ".zip"
                    contador=0
                    f = open(nombrearchivo, "wb")
                    print("se crea f")
                    try:
                        print("recibe datos del cliente")
                        # Recibir datos del cliente.
                        input_data = socket_cliente.recv(1024)
                        if (input_data):
                            print("Aun quedan datos")
                        else:
                            print("ya no quedan datos por enviar")
                            break
                                    
                    except socket.error:
                        print("Error de lectura.")
                        break
                    else:
                        if input_data:
                            #print("hace algo")
                            # Compatibilidad con Python 3.
                            if isinstance(input_data, bytes):
                                #print("hace algo dentro del if")
                                end = input_data[0] == 1
                            else:
                                #print("hace algo dentro del else")
                                end = input_data == chr(1)
                            if True : #not end:
                                # Almacenar datos.
                                f.write(input_data)
                                #print(contador)
                                #print(end)
                                contador+=1
                            else:
                                #print("deberia detenerse")
                                break
                    print("El archivo se ha recibido correctamente.")
                    f.close()
                    recibido = "recibido"

                if recibido == "listar()":
                    ejemplo_dir = RUTA_ARCHIVOS
                    lista_archivos =[]
                    contenido = os.listdir(ejemplo_dir)
                    recibido= str(contenido)

                    respuesta_servidor = direccion_cliente[0] + " envio: " + recibido
                    socket_cliente.send(respuesta_servidor.encode("utf-8"))
                
                #if recibido == "recuperar()":
                    #pass


                respuesta_servidor = direccion_cliente[0] + " envio: " + recibido
                socket_cliente.send(respuesta_servidor.encode("utf-8"))
            except socket.error:
                print ("Conexion terminada abruptamente por el cliente.")
                print ("Cerrando conexion con el cliente ...")
                socket_cliente.close()
                print ("Conexion con el cliente cerrado.")
                break
            except KeyboardInterrupt:
                print ("\n∫Se interrunpio el cliente con un Control_C.")
                print ("Cerrando conexion con el cliente ...")
                socket_cliente.close()
                print ("Conexion con el cliente cerrado.")
                break

except KeyboardInterrupt:
    print ("\nSe interrumpio el servidor con un Control_C.")
    #socket_cliente.close()
    print ("Cerrando el servicio ...")
    socket_servidor.close()
    print ("Servicio cerrado, Adios!")
