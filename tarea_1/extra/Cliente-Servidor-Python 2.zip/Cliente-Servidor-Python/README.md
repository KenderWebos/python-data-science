# Cliente-Servidor-Python
Aplicacion Cliente-Servidor base implementada con socket en lenguaje Python para la asignatura de Redes de Computadores.
