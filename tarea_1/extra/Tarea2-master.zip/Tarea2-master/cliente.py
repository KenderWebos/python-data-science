#!/usr/bin/python
# -*- coding: utf-8 -*-
# Programa Cliente

#import socket
import socket
import sys
import datetime
import os
from zipfile import ZipFile
from tkinter import Tk
from tkinter.filedialog import askopenfilename, askdirectory, askopenfilenames
import hashlib, re
from functools import partial
from subprocess import call


def seleccionarArchivo():
    Tk().withdraw() 
    filename = askopenfilenames()
    return filename

def comprimirZip(file_com):
    diaactual = datetime.datetime.now()
    nombre = "file_" +str(diaactual) + ".zip"
    filezip = ZipFile(nombre, "w")
    for file in file_com:
        arcname = file.replace("\\", "/")
        arcname = arcname[arcname.rfind("/") + 1:]
        filezip.write(str(file),arcname)
    filezip.close()
    return nombre

def ruta():
    ruta = "/"
    return os.getcwd() + ruta

def encontrarzip(nombre):
    bandera = False
    contador = 0
    archivo = ""
    for i in range(len(nombre)):

        if (bandera):
            archivo = archivo + nombre[i]
        #print(contador)
        if (nombre[i] == ")" and contador < (len(nombre)-1)):
            bandera = True          
        contador = contador +1

    if(bandera):
        return archivo , bandera
    else:
        return nombre , bandera


if len(sys.argv) != 3:
    print ("Agregar la IP del servidor y el puerto donde se ofrece el servicio.")
    sys.exit(0)

IP = sys.argv[1]
PUERTO = int(sys.argv[2])

print ("\nConectandose al servidor ", IP, " en el puerto ", PUERTO, " ...")

try:
    socket_cliente = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    socket_cliente.connect((IP, PUERTO))
except:
    print ("No se puede conectar con el servidor.", IP, " en el puerto ", PUERTO)
    sys.exit(0)

print ("\nConectado al servidor.\n")

print ("\n Introduzca uno de los siguentes comandos para realiazar una accion\n")

print (" 1) Para enviar archivo: e()")
print (" 2) Para listar archivos del servidor: l()")
print (" 3) Para Recuperar archivos del servidor: r() seguido del nombre del archivo en el servidor")
print (" 4) Para Finalizar la aplicacion: f()\n")

try:
    while True:
        mensaje = str(input("Yo >> "))
        socket_cliente.send(mensaje.encode("utf-8"))
        aux_archivo, banderita = encontrarzip(mensaje)
        if(banderita):
                        diaactual = datetime.datetime.now()
                        nombrearchivo =  str(diaactual) + aux_archivo
                        ruta_nombrearchivo = ruta() + nombrearchivo
                        contador=0
                        f = open(ruta_nombrearchivo, "wb")
                        #print("se crea f")
                        try:
                            print("recibe datos del cliente")
                            # Recibir datos del cliente.
                            input_data = socket_cliente.recv(1024)
                            if (input_data):
                                print("Aun quedan datos")
                            else:
                                print("ya no quedan datos por enviar")
                                break
                                                        
                        except socket.error:
                            print("Error de lectura.")
                            break
                        else:
                            if input_data:
                                #print("hace algo")
                                # Compatibilidad con Python 3.
                                if isinstance(input_data, bytes):
                                 #   print("linea 113 hace algo dentro del if")
                                    end = input_data[0] == 1
                                else:
                                    #print("hace algo dentro del else")
                                    end = input_data == chr(1)
                                if not end:
                                    print("Almacenar datos.")
                                    f.write(input_data)
                                  #  print("94->",contador)
                                    #print(end)
                                    contador+=1
                                else:
                                    break
                                    
                        f.close()
                        print("El archivo se ha recibido correctamente.")
                        recibido = socket_cliente.recv(1024).decode('utf-8')
                        print ("Servidor >> " + recibido)


        elif (mensaje == "e()"):
            archivo = comprimirZip(seleccionarArchivo())
            print((archivo))
            f = open(archivo, "rb")
            content = f.read(1024)
            while (content):
                # Enviar contenido.
                socket_cliente.send(content)
                content = f.read(1024)
            f.close()
            recibido = socket_cliente.recv(1024).decode('utf-8')
            print ("Servidor >> " + recibido)


        elif mensaje == "f()":
            break
        elif mensaje == "l()":
            print( socket_cliente.recv(1024).decode('utf-8'))

        else:
            recibido = socket_cliente.recv(1024).decode('utf-8')
            print ("Servidor >> " + recibido)

except socket.error:
    print ("Se perdio la conexion con el servidor.")
except KeyboardInterrupt:
    print ("\nSe interrunpio el cliente con un Control_C.")

finally:
    print ("Terminando conexion con el servidor ...")
    socket_cliente.close()
    print ("Conexion con el servidor terminado.")

