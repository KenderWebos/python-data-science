sudo apt install python3-tk  # para usar interfaz gráfica
sudo apt install python3-pip  # para el uso de la administración de paquetes
sudo apt install gzip   # para el uso de archivos gzip