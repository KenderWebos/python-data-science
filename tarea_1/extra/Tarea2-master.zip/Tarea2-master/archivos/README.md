# Transferencia de archivos

Aplicacion de transferencia de archivos donde se pueden enviar, recuperar y listar archivos desde una computadora a otra mediante sockets.

 | Antes de iniciar los archivos es necesario instalar algunos comandos que se encuentran disponibles en el archivo requerimientos.sh |
 
