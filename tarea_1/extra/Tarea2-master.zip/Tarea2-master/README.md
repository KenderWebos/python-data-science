# Transferencia de archivos

Aplicacion de transferencia de archivos donde se pueden enviar, recuperar y listar archivos de texto desde una computadora a otra mediante sockets.

 | Antes de iniciar los archivos es necesario instalar algunos comandos que se encuentran disponibles en el archivo requerimientos.sh |

 El programa fue puesto a prueba en maquinas virtuales con ubuntu 20.04 con python3. Ambas maquinas virtuales se encontraban en una red NAT
 
Fue desarrollado por: Constanza Garcés, Matías Pino y Pablo Belmar. 