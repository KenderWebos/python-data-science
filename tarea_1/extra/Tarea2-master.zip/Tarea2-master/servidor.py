#!/usr/bin/env python
# -*- coding: utf-8 -*-
# Programa Servidor

import sys
import datetime
import socket
import os
from zipfile import ZipFile
from tkinter import Tk
from tkinter.filedialog import askopenfilename, askdirectory, askopenfilenames
import hashlib, re
import hashlib
from functools import partial
from subprocess import call


def encontrarzip(nombre):
    bandera = False
    contador = 0
    archivo = ""
    for i in range(len(nombre)):

        if (bandera):
            archivo = archivo + nombre[i]
        #print(contador)
        if (nombre[i] == ")" and contador < (len(nombre)-1)):
            bandera = True          
        contador = contador +1

    if(bandera):
        return archivo , bandera
    else:
        return nombre , bandera

def ruta():
    ruta = "/archivos/"
    return os.getcwd() + ruta

def listar(ruta):
    contenido = os.listdir(ruta)
    return str(contenido)


def get_ip():
    s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
    try:
        # doesn't even have to be reachable
        s.connect(('0.0.0.1', 1))
        IP = s.getsockname()[0]
    except Exception:
        IP = '127.0.0.1'
    finally:
        s.close()
    return IP

if len(sys.argv) != 2:
    print ("Agregar el puerto donde se va a ofrecer el servicio desarrollado.")
    sys.exit(0)

IP = get_ip()  
PUERTO = int(sys.argv[1])

print ("\nServicio se va a configurar en el puerto: ", PUERTO, "en el servidor ", IP, "\n")

socket_servidor = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
# Enlace del socket con la IP y el puerto
socket_servidor.bind((IP, PUERTO))
# Escuchar conexiones entrantes con el metodo listen,
# El parametro indica el numero de conexiones entrantes que vamos a aceptar
socket_servidor.listen(2)
print ("Servicio configurado en puerto ", PUERTO, "en el servidor ", IP, "\n")
try:
    while True:
        print ("Esperando conexión de un cliente ...")
        # Instanciar objeto socket_cliente para recibir datos,
        # direccion_cliente recibe la tupla de conexion: IP y puerto
        socket_cliente, direccion_cliente = socket_servidor.accept()
        print ("Cliente conectado desde: ", direccion_cliente)
        while True:
            try:
                recibido = socket_cliente.recv(1024).decode('utf-8')
                print (direccion_cliente[0] + " >> ", recibido)

                
                if (recibido[:3] == "r()"):
                    aux_archivo, banderita = encontrarzip(recibido)
                    archivo = ruta() + aux_archivo
                    print((archivo))
                    f = open(archivo, "rb")
                    content = f.read(1024)
                    while (content):
                        # Enviar contenido.
                        socket_cliente.send(content)
                        content = f.read(1024)
                    f.close()
                    socket_cliente.close()

                    print("Enviado!")

                    recibido = "Enviado !"
                    respuesta_servidor = direccion_cliente[0] + " envio: " + recibido
                    socket_cliente.send(respuesta_servidor.encode("utf-8"))
            
            
            
                elif (recibido[:3] == "e()"):
                        diaactual = datetime.datetime.now()
                        nombrearchivo =  str(diaactual) + ".zip"
                        ruta_nombrearchivo = ruta() + nombrearchivo
                        contador=0
                        f = open(ruta_nombrearchivo, "wb")
                        #print("se crea f")
                        try:
                            print("reciendo datos del cliente")
                            # Recibir datos del cliente.
                            input_data = socket_cliente.recv(1024)
                            if (input_data):
                                print("Aun quedan datos")
                            else:
                                print("ya no quedan datos por enviar")
                                break
                                                        
                        except socket.error:
                            print("Error de lectura.")
                            break
                        else:
                            if input_data:
                                #print("hace algo")
                                # Compatibilidad con Python 3.
                                if isinstance(input_data, bytes):
                                    #print("linea 113 hace algo dentro del if")
                                    end = input_data[0] == 1
                                else:
                                    #print("hace algo dentro del else")
                                    end = input_data == chr(1)
                                if True : #not end:
                                    print("Almacenar datos.")
                                    f.write(input_data)
                                    #print("139 ->",contador)
                                    #print(end)
                                    contador+=1
                
                        f.close()
                        print("El archivo se ha recibido correctamente.")
                        recibido = nombrearchivo
                        respuesta_servidor = direccion_cliente[0] + " envio: " + recibido
                        socket_cliente.send(respuesta_servidor.encode("utf-8"))
              
                elif(recibido[:3] == "l()"):
                    recibido = listar(ruta())
                    print(recibido)
                    respuesta_servidor = direccion_cliente[0] + " envio: " + recibido
                    socket_cliente.send(respuesta_servidor.encode("utf-8"))
                
                elif recibido[:3] == "f()":
                    print ("Cliente finalizo la conexion.")
                    print ("Cerrando la conexion con el cliente ...")
                    socket_cliente.close()
                    print ("Conexion con el cliente cerrado.")
                    break
                else:
                    recibido = "Opcion no valida"
                    respuesta_servidor = direccion_cliente[0] + " envio: " + recibido
                    socket_cliente.send(respuesta_servidor.encode("utf-8"))
                
            except socket.error:
                print ("Conexion terminada abruptamente por el cliente.")
                print ("Cerrando conexion con el cliente ...")
                socket_cliente.close()
                print ("Conexion con el cliente cerrado.")
                break
            except KeyboardInterrupt:
                print ("\n∫Se interrunpio el cliente con un Control_C.")
                print ("Cerrando conexion con el cliente ...")
                socket_cliente.close()
                print ("Conexion con el cliente cerrado.")
                break
except KeyboardInterrupt:
    print ("\nSe interrumpio el servidor con un Control_C.")
    #socket_cliente.close()
    print ("Cerrando el servicio ...")
    socket_servidor.close()
    print ("Servicio cerrado, Adios!")
